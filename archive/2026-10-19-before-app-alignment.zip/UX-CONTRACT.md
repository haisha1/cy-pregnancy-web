# UX Contract

## Product context

- Audience：内容编辑、内容审核人员、发布人员、安全管理员。
- Primary jobs：观察数据、维护知识、独立审核、发布下架、维护账号、追溯操作。
- Target market：中国大陆内部运营管理。
- Active locales：zh-CN。
- Language policy：界面和可访问名称使用简体中文；专业术语以 PRD 和后端契约为准。
- Timezone/calendar：Asia/Shanghai，公历；接口 UTC 时间转换后展示。
- Accessibility target：WCAG 2.2 AA。

## Business-context sources

| Domain / scope | Authoritative source | Source type | Reviewed date |
|---|---|---|---|
| 产品范围和数据边界 | `../docs/prd/01-产品需求文档.md` | PRD | 2026-10-19 |
| 管理端接口与状态流 | `../cy-pregnancy-admin/server/docs/02-接口与业务流程.md` | API/业务流程 | 2026-10-19 |
| 管理权限模型 | `../cy-pregnancy-admin/server/docs/02-接口与业务流程.md` | 权限策略 | 2026-10-19 |
| 管理端数据库边界 | `../cy-pregnancy-admin/server/docs/03-表结构与事务设计.md` | 数据设计 | 2026-10-19 |
| 用户服务现状 | `../cy-pregnancy-server/README.md` | 实现说明 | 2026-10-19 |
| 删除、隐私与健康数据边界 | `../docs/backend/02-服务与接口设计.md` | 服务契约评审稿 | 2026-10-19 |
| 支付/计费 | 不适用 | — | 2026-10-19 |
| 法律/监管文案 | 尚无正式文本；Web 首期不代拟 | 未决 | 2026-10-19 |

## Visual contract

- Project `DESIGN.md`：`./DESIGN.md`。
- Token ownership：UI 实现前由 DESIGN.md 定义，落地后 CSS 变量文件成为运行时唯一映射。
- Runtime source：待技术栈初始化后建立 `src/styles/tokens.css`。
- Mapping：DESIGN.md → tokens.css → 共享组件；页面只引用语义令牌。
- Token drift gate：设计令牌 lint、静态项目审计和代表页面视觉回归。
- Supported themes：首期浅色；深色大屏只在单独设计与对比度验证后加入。

## Canonical UI Map

| Capability | Canonical owner | Source of truth | Allowed variants | Verification |
|---|---|---|---|---|
| Table Selection | 首期不做批量选择 | 本契约 | page | 页面审查 |
| Select/Listbox | 共享 Select 组件 | 本契约 + DESIGN.md | authored | 键盘与弹层测试 |
| Date | 共享日期范围组件 | 本契约 | authored | zh-CN、键盘、边界测试 |
| Form | 共享 Field/Form 适配层 | 本契约 | create / edit | 表单 E2E |
| Scrollbar | 全局应用样式 | DESIGN.md | stable-gutter | 计算样式 |
| Toast | 全局通知 Provider | 本契约 | success/warning/info/error | live-region 测试 |
| CRUD | 路由 + 服务层 + 表单壳 | 本契约和后端接口 | return / stay | 完整流程 E2E |

## Component behavior

| Component | Default | Hover | Focus | Active | Disabled | Busy | Error |
|---|---|---|---|---|---|---|---|
| Button | 清晰标签 | 色面增强 | 2px focus ring | 轻微压暗 | 降低对比并说明原因 | 保持尺寸、显示进度 | 就地状态或表单提示 |
| Icon button | 图标+可访问名 | 背景显现 | focus ring | 压暗 | 不触发 | 禁止重复操作 | 邻近提示 |
| Input | 标签在上 | 边框增强 | focus ring | n/a | 只读外观明确 | n/a | 文本错误+aria-invalid |
| Secret input | 默认遮蔽 | 同输入 | 同输入 | n/a | 同输入 | n/a | 不回显秘密 |
| Search | 非空时有清除按钮 | 边框增强 | focus ring | n/a | 说明不可搜索原因 | 局部进度 | 保留查询并可重试 |
| Textarea | resize none | 边框增强 | focus ring | n/a | 只读态 | 提交按钮忙碌 | 保留内容并定位错误 |
| Table/list | 稳定表头和行 | 行底色 | 行内操作可见焦点 | 选中态 | 不隐藏必要信息 | 覆盖内容区不挪动表头 | 稳定区域内重试 |

## Dataset navigation

- Admin tables：服务端分页。现有后端游标分页页面显示“上一页/下一页”；新增接口若提供总数可使用页码分页。
- URL state：关键词、筛选、排序、游标/页码和每页数量写入 URL，返回列表时恢复。
- Page size：默认 20，可选 20/50/100；与后端最大 100 一致。
- States：空数据提供主要动作；无结果提供清除条件；错误提供重试；加载保持表格框架稳定。
- Back restoration：恢复查询、筛选、分页和滚动位置。
- Selection：首期没有批量操作，不显示选择框。

## Flow ledger

| Operation | Trigger | Pending | Success destination | Success feedback | Failure recovery | Focus outcome | Source ref |
|---|---|---|---|---|---|---|---|
| 创建知识 | 点击新建 | 禁用提交，保留表单 | 知识详情 | “草稿已创建” | 保留输入、就地重试 | 详情标题 | 管理接口流程 |
| 编辑草稿 | 点击保存草稿 | 按钮忙碌 | 留在编辑页 | “草稿已保存” | 保留输入，处理版本冲突 | 页面状态区 | 管理接口流程 |
| 提交审核 | 点击提交审核并确认 | 弹窗内等待 | 知识详情 | “已提交审核” | 弹窗保留错误 | 状态标题 | 管理接口流程 |
| 审核 | 批准或驳回 | 禁止重复提交 | 审核队列 | 对应结果提示 | 保留审核意见 | 下一条或队列标题 | 管理接口流程 |
| 发布 | 点击发布并确认 | 弹窗内等待 | 发布中心 | “管理库已发布” | 弹窗内重试 | 已发布行 | 管理接口流程 |
| 下架 | 点击下架并确认 | 弹窗内等待 | 知识详情 | “已从管理库下架” | 弹窗内重试 | 状态标题 | 管理接口流程 |
| 搜索 | 输入完成 300ms 或回车 | 表格局部加载 | 留在列表 | 无额外 toast | 保留查询、可重试 | 搜索框或首行 | 本契约 |
| 修改管理员 | 保存 | 按钮忙碌 | 管理员列表 | “管理员已更新” | 保留表单 | 更新行 | 管理接口流程 |
| 取消/返回 | 点击取消/返回 | 无 | 来源列表 | 无 | 脏表单先确认 | 来源触发点 | 本契约 |

## Navigation and responsive behavior

- `document.title`：`页面名 · 产科工具管理后台`；加载、403、404 和错误页都有真实标题。
- 403 保留应用导航并说明权限不足；404 提供返回总览。
- 侧栏表达一级模块，面包屑表达层级，页签只表达同一资源的视图切换。
- 小于 1280px 收起为图标侧栏，小于 1024px 使用模态抽屉。
- 表格窄屏使用横向滚动并固定首个识别列和操作列，不静默隐藏字段。
- 被截断的 UUID、requestId、标题可通过聚焦后的详情层或复制操作查看完整值。
- 吸附顶栏和操作栏不能遮住键盘焦点。

## Overlays and feedback

- Dialog：使用共享可访问对话框，管理焦点、背景 inert、Escape、滚动锁和焦点恢复。
- Confirmation：送审使用中性确认；角色/状态变更使用警告；永久删除才使用危险确认。
- Toast：右上角单队列，成功 4 秒，信息 6 秒，错误不自动消失；重复消息合并。
- Persistent alert：权限变化、内容未分发、系统依赖异常使用页面内提示，不只依赖 toast。
- Tooltip：仅补充说明，键盘聚焦可触发，Escape 关闭。
- Unsaved changes：应用内导航使用自有确认框；真正关闭页面使用 beforeunload。
- Layer order：dialog > drawer > popover > tooltip；toast 置于全局通知层且不遮挡主要操作。

## Async and resilience

- Mutation default：悲观更新，服务端确认后显示成功。
- Idempotency：知识和管理员写操作生成并复用单次动作 UUID；超时重试复用原 key，修改载荷必须新建动作。
- Draft recovery：首期至少在内存保存未提交输入；是否使用本地持久化需另行安全评审。
- Offline：可读页面显示已有内容和离线提示；写操作不进入离线队列。
- Retry：查询可手动重试；写操作仅在幂等语义明确时重试。
- Conflict：If-Match 409 时保留当前输入，展示服务端已更新提示，允许打开最新版本比较。
- Session expiry：保存安全的非敏感编辑上下文，登录后返回原页面；密码变更后重新登录。
- Stale requests：搜索和筛选取消旧请求，旧响应不得覆盖新结果。
- Mutation failure：对话框和表单保持打开，输入不丢失。

## Validation

- 表单关闭浏览器原生验证气泡，由应用显示中文错误。
- 初次输入不立即报错；提交时校验，错误字段之后在 blur/change 时复核。
- 长表单显示顶部错误摘要与字段内错误，并聚焦第一个错误字段。
- 服务端字段错误映射到字段，全局错误显示在表单状态区。
- 密码默认遮蔽，显示/隐藏按钮可键盘操作；密码、token 不进入 URL、日志、toast 或分析。

## Permission and clipboard

- 导航隐藏完全无关的模块；同页内因状态或权限暂不可用的动作显示禁用并解释原因。
- 直接访问无权限路由显示 403，服务端仍执行最终鉴权。
- UUID/requestId 可显示截断预览并显式复制；toast 只说“已复制”，不回显值。

## Verification

- Required static：DESIGN.md lint、premium strict audit、格式化、类型检查和生产构建。
- Browser matrix：Chrome/Edge 最新版；1280×720、1440×900、1920×1080，另测 1024px 抽屉临界点。
- Accessibility：键盘全流程、焦点、对比度、表单错误、对话框、live region、减少动态。
- Canonical sibling：知识列表→编辑→送审和审核队列→审核详情→返回队列两条完整流程。
- CRUD and failure：创建/编辑/状态流、401、403、409、422、429、503、超时及重复提交。

